# DA-Project-on-HR-ANALYSIS
This project encompasses Tableau dashboards, Power BI dashboards, and SQL queries.
